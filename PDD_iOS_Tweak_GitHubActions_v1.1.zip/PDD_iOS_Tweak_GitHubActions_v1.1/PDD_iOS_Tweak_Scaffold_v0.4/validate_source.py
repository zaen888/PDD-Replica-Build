#!/usr/bin/env python3
"""Portable static checks for the PDD ReplicaShell source; not a compiler or device test."""
from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parent
src = (root / "Tweak.xm").read_text(encoding="utf-8")
makefile = (root / "Makefile").read_text(encoding="utf-8")
control = (root / "control").read_text(encoding="utf-8")
filter_text = (root / "PDDReplicaShell.plist").read_text(encoding="utf-8")

checks = {
    "Logos JSONSerialization hook exists": "%hook NSJSONSerialization" in src and "JSONObjectWithData:" in src,
    "original JSON parser is called": "id parsed = %orig;" in src,
    "capture is gated by enabled state": "PDDCaptureEnabled()" in src,
    "goods ID is filename-sanitized": "PDDSafeGoodsID" in src and "allowed.invertedSet" in src,
    "per-call NSData snapshot exists": "NSData *snapshot = [data copy];" in src,
    "task is bound at capture time": "NSDictionary *taskSnapshot = PDDActiveTaskSnapshot();" in src and "PDDQueueCloudUpload(snapshot, goodsID, taskSnapshot)" in src,
    "atomic local file write exists": "NSDataWritingAtomic" in src,
    "capture queue is serial": "dispatch_queue_create(\"com.local.pddreplica.capture\", DISPATCH_QUEUE_SERIAL)" in src,
    "ZIP uses CRC32 and central directory": "crc32(" in src and "0x02014b50" in src and "0x06054b50" in src,
    "ZIP export runs on a utility queue": "dispatch_get_global_queue(QOS_CLASS_UTILITY, 0)" in src,
    "export ZIP name is collision-resistant": "NSUUID.UUID.UUIDString" in src,
    "Theos links zlib": "PDDReplicaShell_LIBRARIES = z" in makefile,
    "package version is 1.1.0": bool(re.search(r"(?m)^Version:\s*1\.1\.0\s*$", control)),
    "runtime config uses app preferences": all(k in src for k in ("PDDReplicaCloudServerURL", "PDDReplicaCloudDeviceID", "PDDReplicaCloudDeviceToken")),
    "runtime config UI exists": "PDDConfigureCloud" in src and "設定本地服務" in src,
    "no compile-time credential header": '#import \"PDDLocalConfig.h\"' not in src and 'PDD_DEVICE_TOKEN' not in src,
    "task polling API exists": "/api/v1/device/tasks/claim" in src,
    "heartbeat API exists": "/api/v1/device/heartbeat" in src,
    "task start API exists": "/api/v1/device/tasks/%@/start" in src,
    "capture upload API exists": "/api/v1/device/captures" in src and "raw_json_base64" in src,
    "pending upload queue exists": "PendingUploads" in src and "PDDFlushPendingUploads" in src,
    "permanent failures are quarantined": "FailedUploads" in src and "PDDQuarantinePendingUpload" in src,
    "request uses device auth headers": 'X-Device-ID' in src and 'X-Device-Token' in src,
    "filter targets Pinduoduo bundle": "com.xunmeng.pinduoduo" in filter_text,
}

failed = False
for label, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}  {label}")
    failed |= not ok
print(f"\n{sum(checks.values())}/{len(checks)} static checks passed.")
print("NOTE: these checks do not prove Theos compilation, injection, HTTPS trust, or correct product capture on a real iPhone.")
sys.exit(1 if failed else 0)
