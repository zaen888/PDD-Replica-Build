# PDD ReplicaShell 1.1.0（GitHub Actions 版）

本版本以原始 PDDReplicaShell v0.4 為基礎，加入本地伺服器任務通訊，並把設備憑證改為 iPhone 執行時輸入。GitHub Repository 不需要、也不應包含真實設備 Token。

## 這版已具備的能力

- 保留原有浮動按鈕、JSON 擷取開關、TXT 本地保存與 ZIP 匯出。
- Hook `NSJSONSerialization JSONObjectWithData:options:error:`，在原始解析成功後檢查商品資料結構。
- 只接受目前程式已識別的資料形狀：根字典內有 `goods` 字典、`sku` 陣列、`price` 字典，且 `goods.goods_id` 可安全作為檔名。
- 本地服務設定改為在插件選單輸入 HTTPS Server URL、Device ID、Device Token，儲存在拼多多 App 的 `NSUserDefaults`；不把真實憑證編譯進 GitHub 源碼或產物。
- 約每 5 秒向本地服務領取任務，約每 15 秒發送設備心跳。
- 有活動任務時，商品 JSON 會以 Base64 JSON 封裝，上傳至 `/api/v1/device/captures`。
- 上傳失敗會先留在 `Documents/PDDGoodsData/PendingUploads`；暫時性網路／伺服器錯誤會重試。格式錯誤或伺服器拒絕的 4xx 檔案會移至 `FailedUploads` 保留，避免卡住後續佇列。
- 在 JSON Hook 當下綁定任務 ID，避免延遲寫檔時錯把舊商品資料歸到下一個任務。

## 目前仍需要人工完成的部分

**本版本不是全自動搜尋器。** 任務送到 iPhone 後，插件會提示關鍵詞並複製到剪貼簿；使用者仍需在拼多多搜尋關鍵詞、進入商品詳情頁。插件只在它觀察到符合條件的 JSON 時擷取並上傳。自動點擊搜尋、商品卡片及詳情頁導覽，尚未實作，也尚未驗證 PDD 6.92.0 的 UI 結構。

此外，本版本仍須在真實 iPhone 11 / iOS 15.5 / 拼多多 6.92.0 環境安裝測試。GitHub Actions 綠燈只代表 Theos 建置成功，不代表注入、TLS、擷取或上傳已通過真機測試。

## GitHub Actions 建置

1. 把 `PDD_iOS_Tweak_Scaffold_v0.4` 資料夾放在 Repository 根目錄。
2. 把 `.github/workflows/build.yml` 放在 Repository 的 `.github/workflows/` 目錄。
3. Push 到 `main`，或在 GitHub Actions 頁面手動執行 `Build PDD ReplicaShell`。
4. 從成功的 Run 下載 Artifact `PDD-ReplicaShell-1.1.0`。其中包含 rootless `.deb` 套件和 `.dylib`。

此 workflow 不讀取、不產生真實 Device Token。不要把 `config.json`、`PDDLocalConfig.h`、CA 私鑰、伺服器私鑰或任何憑證提交至 Repository。

## iPhone 初次設定

1. 安裝 rootless `.deb` 後，開啟拼多多。
2. 點擊浮動按鈕，選「設定本地服務」。
3. Server URL 輸入 Windows 電腦的 HTTPS LAN 網址，例如 `https://192.168.31.184:8443`（必須與本地伺服器目前設定一致）。
4. Device ID 與 Device Token 從 Windows 專案啟動後產生的 `ios/PDDLocalConfig.h` 讀取。不要把 Token 貼到公開 Repository、Issue 或聊天記錄。
5. 儲存後，插件會開始心跳和領取任務。Windows 管理頁建立任務後，iPhone 會收到任務提示。

若 Windows 本地服務重建了 `config.json` 或更換設備憑證，需在插件選單重新輸入新的值。

## 本地服務 API 合約

插件使用以下設備端 POST API，並透過 HTTPS Header 驗證設備：

- `POST /api/v1/device/heartbeat`
- `POST /api/v1/device/tasks/claim`
- `POST /api/v1/device/tasks/{task_id}/start`
- `POST /api/v1/device/captures`

設備驗證 Header：`X-Device-ID`、`X-Device-Token`。

Capture JSON 欄位：`task_id`、`goods_id`、`captured_at`、`source`、`raw_json_base64`。這與 PDD Local Collector 1.0 後端現有路由相符。

## 靜態檢查

在任何有 Python 3 的環境執行：

```sh
python3 validate_source.py
```

這只檢查源碼結構與接口名稱，不代替 Theos 編譯或真機測試。

## 真機驗證清單

1. 確認 rootless 套件可安裝，拼多多能正常啟動。
2. 確認浮動按鈕點擊會顯示選單，ON/OFF、設定、匯出都正常。
3. 輸入本地 HTTPS URL、Device ID、Token，確認管理頁設備狀態更新為 Online。
4. 建立一個目標數為 1 的測試任務，確認 iPhone 收到關鍵詞提示。
5. 手動在拼多多搜尋並打開一件符合 Hook 條件的商品，確認本地 TXT、伺服器商品記錄及任務 saved_count 更新。
6. 暫時關閉 Windows 服務，確認待上傳 JSON 不會被刪除；服務恢復後確認可重試。
7. 故意輸入錯誤設備 Token，確認錯誤不會把 pending 佇列永久卡住，拒絕檔案保留在 `FailedUploads`。
8. 將拼多多切到背景再返回，確認心跳與任務輪詢會重新啟動。iOS 可能暫停背景中的 App，因此不能假設它能在背景持續工作。

## 隱私與限制

商品 JSON 可能包含商品、分享連結或其他 App 資料；只在你有權測試的設備和資料上使用。插件日誌不輸出整份 JSON。設備 Token 由使用者在插件內輸入，存於拼多多 App 偏好設定，不硬編碼進 GitHub 源碼。此版本不包含反追蹤、TLS challenge 繞過、授權繞過、環境偽裝或其他規避安全機制的功能。
