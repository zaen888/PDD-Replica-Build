# PDD ReplicaShell 1.1.0 — GitHub Actions 專案包

此壓縮包包含可提交到既有 GitHub Repository 的插件源碼目錄與 Actions workflow：

- `PDD_iOS_Tweak_Scaffold_v0.4/`：Theos 插件源碼，已加入任務輪詢、心跳、JSON 上傳及 iPhone 執行時憑證設定。
- `.github/workflows/build.yml`：GitHub Actions macOS 建置工作流程。
- `.gitignore`：避免把本機 Token、憑證、資料庫與建置產物提交到 Repository。

源碼資料夾仍保留舊名稱 `PDD_iOS_Tweak_Scaffold_v0.4`，是為了相容你現有 Actions 的 `cd` 路徑；插件實際套件版本已升級為 **1.1.0**。

**請勿把本專案的 `.gitignore` 理解成伺服器端資料備份。它只用於 Git 排除規則。**

本版沒有完成自動搜尋／自動點擊商品 UI，仍需人工在拼多多搜尋及進入詳情頁。GitHub Actions 只負責編譯，不代表真機測試已通過。
