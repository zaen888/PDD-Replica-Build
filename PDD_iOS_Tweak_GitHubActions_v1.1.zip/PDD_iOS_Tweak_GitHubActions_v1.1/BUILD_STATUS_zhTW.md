# 新版插件建置狀態

版本：PDD ReplicaShell 1.1.0

## 已完成

- 使用本地採集器目錄內已有的任務通訊插件源碼作為底稿。
- 保留原本 JSON Hook、本地 TXT、ZIP 匯出。
- 加入任務領取、設備心跳、商品 JSON 上傳。
- 改為 iPhone 執行時設定伺服器 URL／設備 ID／設備 Token，GitHub 源碼不需要真實憑證。
- 擷取時固定當下任務 ID，避免延遲寫檔後誤關聯下一個任務。
- 新增失敗上傳隔離資料夾，保留格式錯誤或被伺服器拒絕的檔案。
- 加入 GitHub Actions macOS/Theos 編譯 workflow。
- 靜態檢查：24/24 通過。

## 尚未完成／未驗證

- 本工作環境沒有 Theos 與 iOS SDK，因此沒有在此編譯 `.deb` 或 `.dylib`。
- 沒有在 iPhone 11／iOS 15.5／拼多多 6.92.0 真機安裝測試。
- 尚未驗證 iPhone 實際收到心跳、任務與成功上傳的端到端流程。
- 尚未實作自動搜尋關鍵詞、自動點商品卡片、自動進入詳情頁。

## 下一個驗證點

將專案包中的源碼目錄和 workflow 更新到 GitHub Repository，執行 Actions。綠燈後下載 `PDD-ReplicaShell-1.1.0` Artifact；下一階段才是安裝到 iPhone 逐項驗證連線與商品 JSON 上傳。
